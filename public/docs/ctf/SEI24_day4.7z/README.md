## RushedProtocol

Void hid the final flag in it's most secure server. Our staff managed to capture a conversation between him and the server and also retrieved a strange file. The only problem is that we don't understand most of their conversation, it seems encrypted...

Analyze the captured conversation, enter in Void's machine and recover the last flag.
