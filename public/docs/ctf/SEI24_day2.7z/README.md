## Void Market

Void decided to open a secret market, can you buy that flag and tell me what it's like?
He gave me it's source code, but you can connect to the market using: nc 172.232.43.93 40000