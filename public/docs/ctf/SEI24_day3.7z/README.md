## Magic

I think Void is pulling my leg, he's given me another message to decipher. This time he just gave me a picture of himself and told me to use magic to find the real message. What does he mean by that?